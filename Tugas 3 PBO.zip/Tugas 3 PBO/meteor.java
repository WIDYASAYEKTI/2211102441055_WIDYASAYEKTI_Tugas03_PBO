import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class meteor extends Actor {
    
    public void act() {
        move(5); // Meteor bergerak ke bawah
        if (isTouching(FlappyBird.class)) {
            removeTouching(FlappyBird.class); // Menghapus FlappyBird jika bersentuhan dengan meteor
            explode(); // Panggil metode untuk meledak
            checkGameOver(); // Periksa apakah permainan harus dihentikan
        }
        if (getY() >= getWorld().getHeight() - 1) {
            getWorld().removeObject(null); // Hapus meteor jika mencapai bawah layar
            checkGameOver(); // Periksa apakah permainan harus dihentikan
        }
    }
    
    public void explode() {
        // Tambahkan logika meledak di sini
        GreenfootImage explosion = new GreenfootImage("explosion.png"); // Ganti dengan gambar ledakan yang sesuai
        setImage(explosion);
        Greenfoot.delay(5); // Tahan ledakan selama beberapa frame
        
        // Hapus objek meteor setelah meledak
        getWorld().removeObject(null);
    }
    
    public void moveDown() {
        setLocation(getX(), getY() + 10); // Mengubah posisi meteor ke bawah
    }
    
    public void checkGameOver() {
        if (getWorld().getObjects(FlappyBird.class).isEmpty()) {
            Greenfoot.stop(); // Hentikan permainan jika tidak ada FlappyBird tersisa
        }
    }
}
